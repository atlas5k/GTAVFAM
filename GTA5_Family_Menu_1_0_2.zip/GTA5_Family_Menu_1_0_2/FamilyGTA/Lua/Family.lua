Gui_tab_menu = Menu.Title("GUI_TAB_MENU")
Gui_tab_menu:CenterOption("Main Menu - Lua")

local Casino_carousel_drawin = Gui_tab_menu:BoolOption("Casino carousel drawing")

local Coordinate_axis = Gui_tab_menu:FloatOption("Coordinate axis")

Gui_tab_menu:Option("Generate aerial acceleration bars", function()
    script.run_in_fiber(function (crtspeedm)
    objHash = joaat("ar_prop_ar_speed_ring")
    while not STREAMING.HAS_MODEL_LOADED(objHash) do	
        STREAMING.REQUEST_MODEL(objHash)
        crtspeedm:yield()
    end
    local selfpedPos = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), false)
    local heading = ENTITY.GET_ENTITY_HEADING(PLAYER.PLAYER_PED_ID())
    local obj = OBJECT.CREATE_OBJECT(objHash, selfpedPos.x, selfpedPos.y, selfpedPos.z - Coordinate_axis:get_value(), true, true, false)
    ENTITY.SET_ENTITY_HEADING(obj, heading)
    end)
end)

loopa0 = 0 
local Character_Opacity_Settings = Gui_tab_menu:IntOption("Character Opacity Settings")
local Character_Opacity = Gui_tab_menu:BoolOption("Character Opacity")

Gui_tab_all_players = Menu.Title("GUI_TAB_ALL_PLAYERS")
Gui_tab_all_players:CenterOption("Online Players - Lua")

Gui_tab_players = Menu.Title("GUI_TAB_PLAYERS")
Gui_tab_players:CenterOption("Player Name - Lua")

Gui_tab_self = Menu.Title("GUI_TAB_SELF")
Gui_tab_self:CenterOption("Self Options - Lua")

Gui_tab_teleport = Menu.Title("GUI_TAB_TELEPORT")
Gui_tab_teleport:CenterOption("Teleport Options - Lua")

Gui_tab_weapons = Menu.Title("GUI_TAB_WEAPONS")
Gui_tab_weapons:CenterOption("Weapon Options - Lua")

Gui_tab_vehicle = Menu.Title("GUI_TAB_VEHICLE")
Gui_tab_vehicle:CenterOption("Vehicle Options - Lua")

Gui_tab_world = Menu.Title("GUI_TAB_WORLD")
Gui_tab_world:CenterOption("Game World - Lua")

Gui_tab_model_swapper = Menu.Title("GUI_TAB_MODEL_SWAPPER")
Gui_tab_model_swapper:CenterOption("Model Plugin - Lua")

Gui_tab_model_script = Menu.Title("GUI_TAB_MODEL_SCRIPT")
Gui_tab_model_script:CenterOption("Network Events - Lua")

Gui_tab_attribute = Menu.Title("GUI_TAB_ATTRIBUTE")
Gui_tab_attribute:CenterOption("Attribute Adjustments - Lua")

Gui_tab_interface = Menu.Title("GUI_TAB_INTERFACE")
Gui_tab_interface:CenterOption("Settings Options - Lua")

Gui_tab_interface:Option("Display a prompt in the window", function ()
    log.info("I will display a log message in the black window")
end)

script.register_looped("Game Loops", function()

    if  Character_Opacity:is_enabled() then
        ENTITY.SET_ENTITY_ALPHA(PLAYER.PLAYER_PED_ID(), Character_Opacity_Settings:get_value(), false)
    else
        ENTITY.SET_ENTITY_ALPHA(PLAYER.PLAYER_PED_ID(), 255, false)
    end

    if  Casino_carousel_drawin:is_enabled() then
        locals.set_int("casino_lucky_wheel","290","18")
    end

end)